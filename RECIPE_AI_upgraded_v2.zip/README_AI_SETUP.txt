RE:CIPE AI 연결 버전

구성
- GitHub Pages: 기존 RE:CIPE 화면 유지
- Vercel Serverless Function: /api/recipe
- OpenAI API: 실제 AI 분석

1. 이 폴더를 GitHub 저장소에 올립니다. index.html, api/recipe.js, package.json이 같은 프로젝트에 있어도 되고, 백엔드만 별도 저장소로 만들어도 됩니다.
2. Vercel에서 해당 프로젝트를 Import합니다.
3. Environment Variables에 다음을 추가합니다.
   OPENAI_API_KEY = 본인의 OpenAI API 키
   ALLOWED_ORIGIN = https://pagkoon-png.github.io
4. 배포가 끝나면 백엔드 주소가 예를 들어 https://recipe-ai-xxxx.vercel.app 가 됩니다.
5. index.html에서
   const AI_API_URL = "YOUR_AI_BACKEND_URL/api/recipe";
   를 실제 주소로 바꿉니다.
   예: const AI_API_URL = "https://recipe-ai-xxxx.vercel.app/api/recipe";
6. 수정한 index.html을 기존 GitHub Pages 저장소에 다시 올립니다.

중요
- OPENAI_API_KEY는 절대로 index.html에 넣지 않습니다.
- API 키는 Vercel 환경변수에만 넣습니다.
- AI 호출은 실제 API 사용량에 따라 비용이 발생할 수 있습니다.
- 텍스트 요청은 저가 모델(gpt-6-luna), 사진 요청은 이미지 입력을 지원하는 gpt-6-astra를 사용하도록 구성했습니다.
